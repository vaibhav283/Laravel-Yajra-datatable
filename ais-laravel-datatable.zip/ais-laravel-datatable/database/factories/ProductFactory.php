<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */
class ProductFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $randomImages =[
            '41WpqIvJWRL._AC_UY436_QL65_.jpg',
            '61ghDjhS8vL._AC_UY436_QL65_.jpg',
            '61c1QC4lF-L._AC_UY436_QL65_.jpg',
            '710VzyXGVsL._AC_UY436_QL65_.jpg',
            '61EPT-oMLrL._AC_UY436_QL65_.jpg',
            '71r3ktfakgL._AC_UY436_QL65_.jpg',
            '61CqYq+xwNL._AC_UL640_QL65_.jpg',
            '71cVOgvystL._AC_UL640_QL65_.jpg',
            '71E+oh38ZqL._AC_UL640_QL65_.jpg',
            '61uSHBgUGhL._AC_UL640_QL65_.jpg',
            '71nDK2Q8HAL._AC_UL640_QL65_.jpg'
       ];
        return [
            'name' => fake()->name(),
            'description' => fake()->paragraph(),
            'image' => $randomImages[rand(0, 10)],
            'status' =>  'Active',
            'category_id' => rand(1, 5)
        ];
    }
}
