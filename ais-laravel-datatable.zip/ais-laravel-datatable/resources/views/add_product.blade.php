<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Add product</title>
    <style>
        span.error {color:red; font-size: 14px}
    </style>
</head>

<body>

    <div class="container mt-5">
        <h3 class="mb-5">Add Product </h3>

        <form action="{{ route('product.save') }}" method="POST" enctype="multipart/form-data" id="frmAddProduct">
        @csrf
            <div class="form-group">
                <label for="category">Category</label>
                <select class="form-control" id="category" name="category">
                    <option value="">Select</option>
                    @foreach ($categoryList as $category)
                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                    @endforeach
                </select>
                @if ($errors->has('category'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('category') }}</span>
                @endif
            </div>
            <div class="form-group">
                <label for="productName">Name</label>
                <input type="text" class="form-control" name="name" id="name" placeholder="Product name">
                @if ($errors->has('name'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('name') }}</span>
                @endif
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                @if ($errors->has('description'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('description') }}</span>
                @endif
            </div>
            <div class="form-group">
                <label for="imgfile">Product Image</label>
                <input type="file" class="form-control-file" id="imgfile" name="imgfile" accept=".jpg, .jpeg, .png" />
                @if ($errors->has('imgfile'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('imgfile') }}</span>
                @endif
            </div>
            <div class="form-group">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="status" name="status">
                    <label class="form-check-label" for="status"> Active </label>
                </div>
            </div>
            <div class="form-group mt-2">
                <a href="{{ route('product')}}" class="btn btn-light float-left">Cancel</a>
                <button type="submit"  class="btn btn-primary float-right">Submit</button>
            </div>
        </form>
    </div>


    <script type="text/javascript" src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
        integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous">
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
        $("#frmAddProduct").validate({
            errorElement: 'span',
            rules: {
                category: {
                    required: true
                },
                name: {
                    required: true,
                    minlength: 3
                },
                description: {
                    required: true
                },
                imgfile:{
                    required: true,
                    extension: "jpg|jpeg|png"
                }

            },
            messages: {
                category: {
                    required: "Please select category",
                },
                name: {
                    required: "Please enter product name",
                    minlength: 'Minimum 3 characters'
                },
                description: {
                    required: "Please enter description",
                },
                imgfile:{
                    required: "Please select image",
                    extension: "In-correct file format, use jpeg,png,jpg"
                }
            }
        });
    });
    </script>

</body>

</html>
