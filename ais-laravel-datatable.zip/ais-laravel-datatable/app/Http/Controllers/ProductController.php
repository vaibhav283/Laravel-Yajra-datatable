<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use DataTables;
use Exception;


class ProductController extends Controller
{
    public function index()
    {
        return view('products');
    }

    public function getProductList(Request $request) {

        if($request->ajax()) {
            //$data = Product::latest()->get();
            $data = Product::with('category')->latest();

            return Datatables::eloquent($data)
                ->addIndexColumn()
                ->addColumn('category', function($data) {

                    return $data->category->name;
                })
                ->addColumn('image', function($data) {
                    $imgWithPath = asset('storage/'.$data->image);
                    $imgTag = '<img src="'.$imgWithPath.'" width="50px"/>';
                    return $imgTag;
                })
                ->addColumn('status', function() {
                    $statusTag = '<a href="javacscript:void(0)" class="btn btn-success btn-sm">Active </a>';
                    return $statusTag;
                })
                ->addColumn('action', function($data) {
                    $actionBtn = '<a href="' . route('product.edit', $data->id) . '" class="edit btn btn-success btn-sm">Edit </a> &nbsp; | &nbsp; <a href="javascript:void(0)" class="delete btn btn-danger btn-sm deleteProduct"  data-id="'.$data->id.'"> Delete </a>';
                    return $actionBtn;
                })
                ->rawColumns(['image','status', 'action'])
                ->make(true);
        }
    }

    public function add()
    {
        $categoriesList = Category::orderBy('name', 'asc')->where('status', '=', 'Active')->get();
        return view('add_product', ['categoryList' => $categoriesList]);
    }

    /**
     * Save a new record.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function save(Request $request)
    {
        //dd($request->input());
        $request->validate([
            'category'          => 'required',
            'name'              => 'required|min:3',
            'description'       => 'required',
            'imgfile'           => 'required|mimes:jpeg,png,jpg,gif|max:2048',
        ],
        [
            'category.required'         => 'Please select category',
            'name.required'             => 'Please enter product name',
            'name.min'                  => 'Minimum 3 characters',
            'description.required'      => 'Please enter product description',
            'imgfile.required'          => 'Please select image',
            'imgfile.mimes'             => 'In-correct file format, use jpeg,png,jpg',
        ]);

        try{

            $product = new Product;
            $product->category_id    = $request->category;
            $product->name           = $request->name;
            $product->description    = $request->description;
            $product->status         = ($request->status=='on') ? 'Active' : 'In-Active';

            // Upload image into the folder storage/app/product_img
            if ($request->hasFile('imgfile')) {
                $imagePath = $request->file('imgfile')->store('product_img', 'public');
            } else $imagePath = null;

            $product->image = $imagePath;
            $product->save();
            return redirect()->route('product')->with('success','Product added successfully.');
        }catch(Exception $e) {
            return redirect()->route('product.add')->with('error','Something went wrong, please try again');
        }
    }

    public function edit($id)
    {
        $product = Product::findOrFail($id);
        $categoriesList = Category::orderBy('name', 'asc')->where('status', '=', 'Active')->get();
        return view('edit_product', ['product' => $product, 'categoryList' => $categoriesList]);
    }

    /**
     * Update the record.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'category'          => 'required',
            'name'              => 'required|min:3',
            'description'       => 'required',
            'imgfile'           => 'mimes:jpeg,png,jpg,gif|max:2048',
        ],
        [
            'category.required'         => 'Please select category',
            'name.required'             => 'Please enter product name',
            'name.min'                  => 'Minimum 3 characters',
            'description.required'      => 'Please enter product description',
            'imgfile.mimes'             => 'In-correct file format, use jpeg,png,jpg',
        ]);

        try{
            $product = Product::find($id);
            $product->category_id    = $request->category;
            $product->name           = $request->name;
            $product->description    = $request->description;
            $product->status         = ($request->status=='on') ? 'Active' : 'In-Active';

            // Upload image into the folder storage/app/product_img
            if ($request->hasFile('imgfile')) {
                $imagePath = $request->file('imgfile')->store('product_img', 'public');
                $product->image = $imagePath;
            }
            $product->save();
            return redirect()->route('product')->with('success','Product updated successfully.');
        }catch(Exception $e) {
            return redirect()->route('product.edit')->with('error','Something went wrong, please try again');
        }
    }


    /**
     * Remove the record from db
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::find($id);

        if ($product) {
            $product->delete();
            return response()->json(['message' => 'Product deleted successfully', 'success' => 1]);
        } else {
            return response()->json(['error' => 'Product not found', 'success' => 0], 404);
        }
    }
}
