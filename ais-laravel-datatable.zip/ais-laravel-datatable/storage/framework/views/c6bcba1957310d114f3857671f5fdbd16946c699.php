<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/jquery.dataTables.min.css" integrity="sha512-1k7mWiTNoyx2XtmI96o+hdjP8nn0f3Z2N4oF/9ZZRgijyV4omsKOXEnqL1gKQNPy2MTSP9rIEWGcH/CInulptA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <title>Product List</title>

  </head>
  <body>

    <div class="container mt-5">
        <h3 class="mb-5">Product List
            <a href="<?php echo e(route('product.add')); ?>" class="btn btn-primary float-right">Add Product</a>
        </h3>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h5><i class="icon fas fa-check"></i> Alert!</h5> <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <table class="table table-bordered product-datatable"  id='product-datatable'>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Image</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js" integrity="sha512-BkpSL20WETFylMrcirBahHfSnY++H2O1W+UnEEO4yNIl+jI2+zowyoGJpbtk6bx97fBXf++WJHSSK2MV4ghPcg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/dataTables.bootstrap4.min.js" integrity="sha512-OQlawZneA7zzfI6B1n1tjUuo3C5mtYuAWpQdg+iI9mkDoo7iFzTqnQHf+K5ThOWNJ9AbXL4+ZDwH7ykySPQc+A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script type="text/javascript">

        $(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('.product-datatable').DataTable({
                processing:true,
                serverSide: true,
                ajax: "<?php echo e(route('product.list')); ?>",
                columns:[
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                    {data: 'name', name:'name'},
                    {data: 'category', name:'category.name'},
                    {data: 'image', name:'image'},
                    {
                        data:'status',
                        name:'status',
                        orderable:true,
                        searchable:true
                    },
                    {
                        data:'action',
                        name:'action',
                        orderable:true,
                        searchable:true
                    },
                ]
            })

            // Delete record
            $('#product-datatable').on('click','.deleteProduct',function(){

                var id = $(this).data('id');
                var deleteConfirm = confirm("Are you sure?");

                if (deleteConfirm == true) {
                    // AJAX request
                    $.ajax({
                        "url": "<?php echo e(url('product/delete')); ?>/"+id,
                        type: 'GET',
                        data: {_token: '<?php echo e(csrf_token()); ?>', id: id},
                        success: function(response){
                            if(response.success == 1){
                                alert("Record deleted.");
                                table.ajax.reload(); // Reload DataTable
                            }else{
                                alert("Invalid ID.");
                            }
                        }
                    });
                }
            });
        });

    </script>

  </body>
</html>
<?php /**PATH I:\xampp\htdocs\ais-laravel-datatable\resources\views/products.blade.php ENDPATH**/ ?>